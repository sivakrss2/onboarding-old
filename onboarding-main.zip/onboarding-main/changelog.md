## CHANGE LOG:

v2.0.0:
 - Update to Angular 7
 
v1.3.0:
  - Header logo routerLink option

v1.2.8:
 - fix layout wrapper overflow

v1.2.0:
 - Lib creation and tests with angular-cli

v1.1.1:
 - Update admin-lte to 2.4.3
 - Change admin-lte dependency to admin-lte-css
 - Remove bootstrap dependency

v1.0.1:
- Fix ie bug

v1.0.0:
 - Update to angular 6
