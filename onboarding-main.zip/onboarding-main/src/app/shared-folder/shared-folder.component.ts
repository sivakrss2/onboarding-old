import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shared-folder',
  templateUrl: './shared-folder.component.html',
  styleUrls: ['./shared-folder.component.css']
})
export class SharedFolderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
