var menu = [];

export const adminLteConf = {
  skin: 'blue',  
  sidebarLeftMenu: menu,
};
