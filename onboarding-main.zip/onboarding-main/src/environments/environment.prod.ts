export const environment = {
  production: true,
  // apiUrl: 'http://202.129.196.133/boarding-system'
  // apiUrl: 'http://202.129.196.133/onboarding-api'
  // apiUrl: 'http://106.51.50.95:5428/onboard-api'
  
  apiUrl: 'http://172.16.0.77:8085/onboard-api'
  
  // apiUrl: 'http://cgvakstage.com:8085/onboard-api'
};
